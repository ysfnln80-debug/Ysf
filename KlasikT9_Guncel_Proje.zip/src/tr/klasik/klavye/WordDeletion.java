package tr.klasik.klavye;
/** UTF-16 length of the previous word, with trailing whitespace/punctuation. */
public final class WordDeletion {
 private WordDeletion(){}
 private static boolean space(int c){return Character.isWhitespace(c)||Character.isSpaceChar(c);}
 private static boolean word(int c){int type=Character.getType(c);return Character.isLetterOrDigit(c)||type==Character.NON_SPACING_MARK||type==Character.COMBINING_SPACING_MARK||c=='\''||c==0x2019||c=='_';}
 public static int beforeCursor(String text){int end=text.length(),i=end;while(i>0&&space(text.codePointBefore(i)))i-=Character.charCount(text.codePointBefore(i));while(i>0&&!space(text.codePointBefore(i))&&!word(text.codePointBefore(i)))i-=Character.charCount(text.codePointBefore(i));while(i>0&&word(text.codePointBefore(i)))i-=Character.charCount(text.codePointBefore(i));return end-i;}
}
