package tr.klasik.klavye;
import java.util.*;import java.nio.charset.StandardCharsets;
/** Ordered local text clips only; sensitive clipboard items are excluded by the caller. */
public final class ClipboardHistory {
 public static final int LIMIT=20,MAX_LENGTH=4000;private final ArrayList<String> clips=new ArrayList<>();
 public void add(String text){if(text==null||text.trim().isEmpty())return;if(text.length()>MAX_LENGTH)text=text.substring(0,MAX_LENGTH);clips.remove(text);clips.add(0,text);while(clips.size()>LIMIT)clips.remove(clips.size()-1);}
 public List<String> list(){return new ArrayList<>(clips);}public void clear(){clips.clear();}
 public String save(){StringBuilder b=new StringBuilder();for(String s:clips){if(b.length()>0)b.append('\n');b.append(Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8)));}return b.toString();}
 public void load(String data){clips.clear();String[] rows=data.split("\n");for(int i=Math.min(rows.length,LIMIT)-1;i>=0;i--)try{add(new String(Base64.getDecoder().decode(rows[i]),StandardCharsets.UTF_8));}catch(IllegalArgumentException ignored){}}
}
