package tr.klasik.klavye;
/** One action per leftward drag; vertical or cancelled gestures never delete. */
public final class SwipeDeleteGesture {
 private final float distance,vertical,slop;private float x,y,dx;private boolean active,moved,blocked;
 public SwipeDeleteGesture(float distance,float vertical,float slop){this.distance=distance;this.vertical=vertical;this.slop=slop;}
 public void start(float x,float y){this.x=x;this.y=y;dx=0;active=true;moved=false;blocked=false;}
 public void move(float x,float y){if(!active)return;dx=this.x-x;float dy=Math.abs(this.y-y);if(Math.abs(dx)>slop||dy>slop)moved=true;if(dy>vertical)blocked=true;}
 public boolean hasMoved(){return moved;}public boolean shouldDelete(){return active&&!blocked&&dx>=distance;}public void cancel(){active=false;moved=true;}
}
