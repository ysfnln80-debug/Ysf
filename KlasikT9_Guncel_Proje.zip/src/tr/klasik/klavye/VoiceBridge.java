package tr.klasik.klavye;
import java.util.UUID;
/** One short-lived dictation request, bound to the editor that opened the microphone. */
public final class VoiceBridge {
 private static String token,pkg,text;private static int field,type;private static long started;private static boolean active;
 private VoiceBridge(){}
 public static synchronized String begin(String target,int id,int inputType,long now){token=UUID.randomUUID().toString();pkg=target;field=id;type=inputType;started=now;text=null;active=true;return token;}
 public static synchronized boolean valid(String request,long now){if(token==null||now-started>120000||now<started){clear();return false;}return token.equals(request);}
 public static synchronized boolean hasRequest(long now){return valid(token,now);}
 public static synchronized boolean complete(String request,String result,long now){if(!valid(request,now)||result==null||result.trim().isEmpty())return false;text=result.substring(0,Math.min(result.length(),4000));active=false;return true;}
 public static synchronized String pending(String target,int id,int inputType,long now){if(!valid(token,now)||active||!pkg.equals(target)||field!=id||type!=inputType)return null;return text;}
 public static synchronized void cancel(String request){if(token!=null&&token.equals(request))clear();}
 public static synchronized void clear(){token=null;pkg=null;text=null;active=false;}
}
