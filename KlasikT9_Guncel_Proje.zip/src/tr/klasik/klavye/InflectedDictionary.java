package tr.klasik.klavye;
import java.io.*;import java.nio.*;import java.nio.channels.FileChannel;import java.nio.charset.StandardCharsets;import java.util.*;
/** Read-only, disk-backed T9 index. No Android dependency; tested on the JVM. */
public final class InflectedDictionary {
 private final MappedByteBuffer data;private final int count,blob;
 public InflectedDictionary(File file)throws IOException{
  try(RandomAccessFile r=new RandomAccessFile(file,"r")){
   long size=r.length();if(size<12||size>Integer.MAX_VALUE)throw new IOException("Invalid dictionary size");
   data=r.getChannel().map(FileChannel.MapMode.READ_ONLY,0,size);
   if(data.getInt(0)!=0x54394631)throw new IOException("Invalid dictionary header");
   count=data.getInt(4);blob=data.getInt(8);
   if(count<0||12L+count*12L!=blob||blob>size)throw new IOException("Invalid dictionary index");
  }
 }
 public int size(){return count;}
 private static long encode(String digits){if(digits.length()==0||digits.length()>20)return -1;long key=1;for(int i=0;i<digits.length();i++){char c=digits.charAt(i);if(c<'2'||c>'9')return -1;key=(key<<3)|(c-'2');}return key;}
 private int lowerBound(long key){int l=0,h=count;while(l<h){int m=l+(h-l)/2;if(data.getLong(12+m*12)<key)l=m+1;else h=m;}return l;}
 private String wordAt(int i){int start=data.getInt(12+i*12+8),end=i+1<count?data.getInt(12+(i+1)*12+8):data.capacity()-blob;if(start<0||end<start||(long)blob+end>data.capacity()||end-start>200)return "";byte[] bytes=new byte[end-start];ByteBuffer c=data.asReadOnlyBuffer();c.position(blob+start);c.get(bytes);return new String(bytes,StandardCharsets.UTF_8);}
 public List<String> complete(String digits,String literalPrefix,int limit){ArrayList<String> result=new ArrayList<>();long prefix=encode(digits);if(prefix<0||digits.length()<2||limit<=0)return result;int scanned=0;for(int length=digits.length()+1;length<=20&&result.size()<limit&&scanned<4096;length++){int shift=(length-digits.length())*3;long low=prefix<<shift,high=(prefix+1)<<shift;int seen=0;for(int i=lowerBound(low);i<count&&data.getLong(12+i*12)<high&&result.size()<limit&&seen<512&&scanned<4096;i++,seen++,scanned++){String w=wordAt(i);if(!w.isEmpty()&&(literalPrefix==null||w.startsWith(literalPrefix)))result.add(w);}}return result;}
 public List<String> lookup(String digits,int limit){
  ArrayList<String> result=new ArrayList<>();long key=encode(digits);if(key<0||limit<=0)return result;
  int low=0,high=count;while(low<high){int mid=low+(high-low)/2;if(data.getLong(12+mid*12)<key)low=mid+1;else high=mid;}
  for(int i=low;i<count&&result.size()<limit&&data.getLong(12+i*12)==key;i++){
   int start=data.getInt(12+i*12+8);int end=i+1<count?data.getInt(12+(i+1)*12+8):data.capacity()-blob;
   if(start<0||end<start||(long)blob+end>data.capacity()||end-start>200)continue;
   byte[] bytes=new byte[end-start];ByteBuffer copy=data.asReadOnlyBuffer();copy.position(blob+start);copy.get(bytes);result.add(new String(bytes,StandardCharsets.UTF_8));
  }
  return result;
 }
}
