package tr.klasik.klavye;
import android.inputmethodservice.InputMethodService;import android.content.*;import android.app.AlertDialog;import android.view.*;import android.view.inputmethod.*;import android.widget.*;import android.graphics.*;import android.os.*;import java.util.*;import java.io.*;
public class KeyboardService extends InputMethodService {
 LinearLayout root, candidates;HorizontalScrollView suggestionStrip; boolean qwerty=false,predict=true,shift=false,symbol=false,dark=true,neon=true,vibrate=true,privateField=false; String digits="",multi="",acceptedWord="",typedPrefix="";boolean nextSuggestions=false,wordClosed=false,fieldAllowsLearning=false;LearningDictionary learned=new LearningDictionary();LinkedHashMap<String,String> basicCodes=new LinkedHashMap<>();int last=-1,index=0;long lastTime=0; Handler handler=new Handler(Looper.getMainLooper()); Runnable timeout=()->finishMulti(); Map<String,ArrayList<String>> dict=new HashMap<>(); ArrayList<String> options=new ArrayList<>(); Locale tr=new Locale("tr","TR");
 static final String[] keyLabels={"","@","abc","def","ghi","jkl","mno","pqrs","tuv","wxyz"};
 static final String[] groups={"",".,?!'","abcç","def","gğhıi","jkl","mnoö","pqrsş","tuüv","wxyz"};
 public void onCreate(){super.onCreate();dark=prefs().getBoolean("dark",true);neon=prefs().getBoolean("neon",true);vibrate=prefs().getBoolean("vibrate",true);qwerty=prefs().getBoolean("qwerty",false);predict=prefs().getBoolean("prediction",true);try{BufferedReader r=new BufferedReader(new InputStreamReader(getAssets().open("words.txt"),"UTF-8"));String s;while((s=r.readLine())!=null){addWord(s.trim());basicCodes.put(s.trim(),code(s.trim()));}r.close();}catch(Exception e){}reloadPersonal();loadLearned();loadInflectionsAsync();setupClipboard();}
 android.content.SharedPreferences prefs(){return getSharedPreferences("settings",0);} int dp(int n){return (int)(getResources().getDisplayMetrics().density*n+.5f);} int fg(){return neon?0xff9ffcff:(dark?0xfff1f3f5:0xff202735);} int bg(){return neon?0xff070917:(dark?0xff20252d:0xffd5d9df);}
 String code(String w){StringBuilder b=new StringBuilder();for(char c:w.toLowerCase(tr).toCharArray()){boolean found=false;for(int i=2;i<=9;i++)if(groups[i].indexOf(c)>=0){b.append(i);found=true;break;}if(!found)return "";}return b.toString();}
 void addWord(String w){String c=code(w);if(c.isEmpty())return;ArrayList<String> a=dict.get(c);if(a==null){a=new ArrayList<>();dict.put(c,a);}if(!a.contains(w))a.add(w);}
 Map<String,ArrayList<String>> originalPersonalCodes=new HashMap<>();
 void reloadPersonal(){for(Map.Entry<String,ArrayList<String>> e:originalPersonalCodes.entrySet()){if(e.getValue().isEmpty())dict.remove(e.getKey());else dict.put(e.getKey(),new ArrayList<>(e.getValue()));}originalPersonalCodes.clear();ArrayList<String> personal=new ArrayList<>(prefs().getStringSet("words",new HashSet<String>()));Collections.sort(personal);for(String w:personal){String c=code(w);if(c.isEmpty())continue;if(!originalPersonalCodes.containsKey(c))originalPersonalCodes.put(c,dict.containsKey(c)?new ArrayList<>(dict.get(c)):new ArrayList<String>());addWord(w);ArrayList<String> a=dict.get(c);a.remove(w);a.add(0,w);}}
 volatile InflectedDictionary inflected;volatile boolean serviceDestroyed=false;
 void loadInflectionsAsync(){new Thread(()->{
  try{
   File cache=new File(getCacheDir(),"inflected-v6.bin");InflectedDictionary loaded=null;
   if(cache.exists())try{loaded=new InflectedDictionary(cache);}catch(IOException invalid){cache.delete();}
   if(loaded==null){File temp=File.createTempFile("t9-inflected-",".tmp",getCacheDir());try{
    try(InputStream in=getAssets().open("inflected-v6.bin");FileOutputStream out=new FileOutputStream(temp)){byte[] buffer=new byte[32768];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);out.getFD().sync();}
    java.nio.file.Files.move(temp.toPath(),cache.toPath(),java.nio.file.StandardCopyOption.REPLACE_EXISTING);loaded=new InflectedDictionary(cache);
   }finally{temp.delete();}}
   if(!serviceDestroyed){inflected=loaded;handler.post(()->{if(!serviceDestroyed&&predict&&!privateField){if(!digits.isEmpty())updatePrediction();else if(!typedPrefix.isEmpty())updateTypedPrediction();}});}
  }catch(IOException e){android.util.Log.e("KlasikT9","Ekli kelime sözlüğü açılamadı",e);}
 },"T9-dictionary").start();}
 public void onDestroy(){if(clipboardManager!=null&&clipboardListener!=null)clipboardManager.removePrimaryClipChangedListener(clipboardListener);flushLearned();serviceDestroyed=true;handler.removeCallbacksAndMessages(null);super.onDestroy();}
 public View onCreateInputView(){render();return root;} public boolean onEvaluateFullscreenMode(){return false;}
 public void onStartInput(EditorInfo e,boolean restarting){super.onStartInput(e,restarting);flushLearned();loadLearned();reloadPersonal();clipboardMode=false;fieldAllowsLearning=LearningPolicy.allows(e.inputType,e.imeOptions);typedPrefix="";nextSuggestions=false;wordClosed=false;options.clear();digits="";multi="";acceptedWord="";last=-1;handler.removeCallbacks(timeout);int v=e.inputType & InputTypeMask();privateField=v==129||v==145||v==225||v==18;symbol=(e.inputType&15)==2||(e.inputType&15)==3;if(root!=null)rebuild();}
 public void onStartInputView(EditorInfo e,boolean restarting){super.onStartInputView(e,restarting);clips.load(prefs().getString("clipboard_clips",""));captureClipboard();handler.postDelayed(()->tryInsertVoice(),150);}
 public void onWindowShown(){super.onWindowShown();handler.postDelayed(()->tryInsertVoice(),200);}
 int InputTypeMask(){return 4095;}
 public void onFinishInput(){clipboardMode=false;currentClip="";currentClipSensitive=false;flushLearned();typedPrefix="";nextSuggestions=false;options.clear();handler.removeCallbacks(timeout);digits="";multi="";acceptedWord="";last=-1;super.onFinishInput();}
 void feedback(View v){if(vibrate)v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);}
 LinearLayout sideLetters;
 int chosenGroup=5;
 class Key extends View {
  String label,number;boolean special;Paint paint=new Paint(3);
  Key(String text,String sub,boolean action,Runnable click,Runnable hold){super(KeyboardService.this);label=text;number=sub;special=action;setClickable(true);setFocusable(true);setContentDescription(text+(sub.isEmpty()?"":" · "+sub));setOnClickListener(v->{feedback(v);click.run();});if(hold!=null)setOnLongClickListener(v->{feedback(v);hold.run();return true;});}
  protected void onDraw(Canvas c){float w=getWidth(),h=getHeight();int top,bottom;if(neon){top=isPressed()?0xff114b64:0xff10142c;bottom=isPressed()?0xff30136a:0xff070a18;}else if(isPressed()){top=0xff007eac;bottom=0xff005475;}else if(dark){top=special?0xff302e31:0xff535154;bottom=special?0xff211f22:0xff414043;}else{top=special?0xffc2c5cb:0xfffafafa;bottom=special?0xffaeb3bc:0xffdcdfe3;}paint.setShader(new LinearGradient(0,0,0,h,top,bottom,Shader.TileMode.CLAMP));c.drawRect(1,1,w-1,h-1,paint);paint.setShader(null);if(neon){paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(isPressed()?2:1));paint.setColor(special?0xffb84dff:0xff00eaff);paint.setShadowLayer(dp(isPressed()?9:5),0,0,paint.getColor());c.drawRoundRect(dp(2),dp(2),w-dp(2),h-dp(2),dp(7),dp(7),paint);paint.clearShadowLayer();paint.setStyle(Paint.Style.FILL);}paint.setColor(neon?0xff383c64:(dark?0xff777579:0xffffffff));paint.setStrokeWidth(1);c.drawLine(2,2,w-2,2,paint);paint.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));paint.setTextAlign(Paint.Align.CENTER);paint.setColor(neon?(special?0xffedc2ff:0xffb8ffff):(dark?0xfff1f0f2:0xff252931));float size=label.length()>7?13:label.length()>4?19:label.length()>2?23:25;paint.setTextSize(dp((int)size));float available=Math.max(dp(8),w-dp(8));if(paint.measureText(label)>available)paint.setTextSize(paint.getTextSize()*available/paint.measureText(label));if((label.startsWith("Tahmin")||label.startsWith("T9"))&&predict)paint.setColor(0xff12bae9);float baseline=h*.50f-(paint.ascent()+paint.descent())/2;c.drawText(label,w/2,baseline,paint);if(!number.isEmpty()){paint.setTextAlign(Paint.Align.RIGHT);paint.setTextSize(dp(13));paint.setColor(neon?0xffd789ff:(dark?0xffb0aeb2:0xff5e626c));c.drawText(number,w-dp(7),h-dp(8),paint);}}
  public void setPressed(boolean b){super.setPressed(b);invalidate();}
 }
 class DeleteKey extends Key {
  SwipeDeleteGesture gesture;
  DeleteKey(){super("⌫","",true,()->back(),()->{for(int i=0;i<5;i++)back();});setContentDescription("Sil; sola 3 ve 2 yönünde kaydırınca kelimeyi sil");}
  void cancelDefaultPress(MotionEvent source){MotionEvent cancel=MotionEvent.obtain(source);cancel.setAction(MotionEvent.ACTION_CANCEL);super.onTouchEvent(cancel);cancel.recycle();cancelLongPress();setPressed(false);}
  public boolean onTouchEvent(MotionEvent event){
   int action=event.getActionMasked();
   if(action==MotionEvent.ACTION_DOWN){gesture=new SwipeDeleteGesture(Math.max(dp(64),root.getWidth()*.30f),Math.max(dp(32),getHeight()*.8f),ViewConfiguration.get(KeyboardService.this).getScaledTouchSlop());gesture.start(event.getRawX(),event.getRawY());getParent().requestDisallowInterceptTouchEvent(true);return super.onTouchEvent(event);}
   if(gesture!=null&&action==MotionEvent.ACTION_MOVE){gesture.move(event.getRawX(),event.getRawY());if(gesture.hasMoved()){cancelLongPress();setPressed(gesture.shouldDelete());return true;}}
   if(gesture!=null&&action==MotionEvent.ACTION_POINTER_DOWN){gesture.cancel();cancelDefaultPress(event);return true;}
   if(gesture!=null&&action==MotionEvent.ACTION_UP){gesture.move(event.getRawX(),event.getRawY());boolean moved=gesture.hasMoved(),delete=gesture.shouldDelete();gesture.cancel();getParent().requestDisallowInterceptTouchEvent(false);if(moved){cancelDefaultPress(event);if(delete){feedback(this);deleteWholeWord();}return true;}}
   if(action==MotionEvent.ACTION_CANCEL){if(gesture!=null)gesture.cancel();getParent().requestDisallowInterceptTouchEvent(false);}
   return super.onTouchEvent(event);
  }
 }
 void deleteWholeWord(){InputConnection ic=getCurrentInputConnection();if(ic==null)return;handler.removeCallbacks(timeout);wordClosed=false;acceptedWord="";typedPrefix="";nextSuggestions=false;options.clear();
  ic.beginBatchEdit();try{CharSequence selected=ic.getSelectedText(0);if(selected!=null&&selected.length()>0){ic.commitText("",1);ic.finishComposingText();}
   else if(!digits.isEmpty()){ic.setComposingText("",1);ic.finishComposingText();}
   else{ic.finishComposingText();CharSequence before=ic.getTextBeforeCursor(4096,0);if(before!=null){int count=WordDeletion.beforeCursor(before.toString());if(count>0)ic.deleteSurroundingText(count,0);}}
  }finally{digits="";multi="";last=-1;ic.endBatchEdit();}refresh();
 }
 Key key(String label,String sub,boolean special,Runnable action,Runnable hold){return new Key(label,sub,special,action,hold);}
 void add(LinearLayout row,View key,float weight,int height){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(height),weight);p.setMargins(dp(1),dp(1),dp(1),dp(1));row.addView(key,p);}
 LinearLayout line(LinearLayout parent){LinearLayout r=new LinearLayout(this);parent.addView(r,new LinearLayout.LayoutParams(-1,-2));return r;}
 void togglePrediction(){finish();predict=!predict;prefs().edit().putBoolean("prediction",predict).apply();options.clear();rebuild();}
 void setCase(){finish();shift=!shift;rebuild();}
 void toggleSymbols(){finish();symbol=!symbol;rebuild();}
 void literal(String val){boolean letter=val.matches("[a-zçğıöşü]");if(!letter)learnBoundary();finish();commit(shift?val.toUpperCase(tr):val);if(letter){wordClosed=false;updateTypedPrediction();}else{typedPrefix="";options.clear();refresh();}}
 int fallbackNavigationBottom(){int id=getResources().getIdentifier("navigation_bar_height","dimen","android");return id!=0?getResources().getDimensionPixelSize(id):dp(48);}
 void configureNavigationInsets(View keyboard){
  keyboard.setOnApplyWindowInsetsListener((v,insets)->{
   int left=0,right=0,bottom=0;
   if(Build.VERSION.SDK_INT>=30){android.graphics.Insets safe=insets.getInsets(WindowInsets.Type.navigationBars()|WindowInsets.Type.displayCutout());left=safe.left;right=safe.right;bottom=safe.bottom;}
   else{left=insets.getSystemWindowInsetLeft();right=insets.getSystemWindowInsetRight();bottom=insets.getSystemWindowInsetBottom();}
   // Only system navigation/cutout insets are used; never add the keyboard's own IME height.
   if(bottom==0)bottom=fallbackNavigationBottom();
   int pad=bottom+dp(8);
   if(v.getPaddingBottom()!=pad||v.getPaddingLeft()!=left+dp(1)||v.getPaddingRight()!=right+dp(1))v.setPadding(left+dp(1),dp(1),right+dp(1),pad);
   return insets;
  });
  keyboard.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(){public void onViewAttachedToWindow(View v){v.requestApplyInsets();}public void onViewDetachedFromWindow(View v){}});
  keyboard.post(()->keyboard.requestApplyInsets());
 }
 void render(){
  root=new LinearLayout(this);root.setOrientation(1);root.setBackgroundColor(neon?0xff030511:0xff080709);root.setPadding(dp(1),dp(1),dp(1),fallbackNavigationBottom()+dp(8));configureNavigationInsets(root);
  LinearLayout tools=line(root);
  add(tools,key("Ayarlar","",true,()->showQuickSettings(),null),1,40);
  add(tools,key("Pano","",true,()->{finish();if(!clipboardMode)captureClipboard();clipboardMode=!clipboardMode;rebuild();},null),1,40);
  add(tools,key("Tema","",true,()->showThemeOptions(),null),1,40);
  add(tools,key("Klavye","",true,()->showKeyboardOptions(),null),1,40);
  if(clipboardMode){candidates=null;renderClipboard();return;}
  HorizontalScrollView sc=new HorizontalScrollView(this);suggestionStrip=sc;sc.setBackgroundColor(neon?0xff070b20:0xff000000);sc.setHorizontalScrollBarEnabled(false);candidates=new LinearLayout(this);sc.addView(candidates);root.addView(sc,new LinearLayout.LayoutParams(-1,dp(48)));refresh();
  if(!qwerty&&!symbol){
   LinearLayout main=line(root);sideLetters=new LinearLayout(this);sideLetters.setOrientation(1);
   main.addView(sideLetters,new LinearLayout.LayoutParams(0,dp(288),.14f));updateSide();
   LinearLayout matrix=new LinearLayout(this);matrix.setOrientation(1);main.addView(matrix,new LinearLayout.LayoutParams(0,dp(288),.68f));
   for(int r=0;r<3;r++){LinearLayout row=line(matrix);for(int col=0;col<3;col++){final int n=r*3+col+1;String label=keyLabels[n];if(shift)label=label.toUpperCase(Locale.ROOT);add(row,key(label,""+n,false,()->{chosenGroup=n;if(n==1)literal("@");else tap(n);updateSide();},()->{finish();commit(""+n);}),1,94);}}
   LinearLayout right=new LinearLayout(this);right.setOrientation(1);main.addView(right,new LinearLayout.LayoutParams(0,dp(288),.18f));
   LinearLayout r=line(right);add(r,new DeleteKey(),1,94);
   r=line(right);add(r,key(shift?"a":"A↑","",true,()->setCase(),null),1,94);
   r=line(right);add(r,key(predict?"T9 ✓":"T9 ×","",true,()->togglePrediction(),null),1,94);
   LinearLayout bottom=line(root);
   add(bottom,key("12#","",true,()->toggleSymbols(),null),.16f,57);
   add(bottom,key(",","",false,()->literal(","),null),.09f,57);
   add(bottom,spaceWithMic(),.56f,57);
   add(bottom,key(".","",false,()->literal("."),null),.09f,57);
   add(bottom,key("Git","",true,()->enter(),null),.10f,57);
  }else{
   sideLetters=null;String[] rows=symbol?new String[]{"1234567890","@#₺%&*-+=",".,?!:;/()"}:new String[]{"qwertyuıopğü","asdfghjklşi","zxcvbnmöç"};
   for(String chars:rows){LinearLayout r=line(root);for(char c:chars.toCharArray()){String val=String.valueOf(c);add(r,key(shift?val.toUpperCase(tr):val,"",false,()->literal(val),null),1,66);}}
   LinearLayout bottom=line(root);add(bottom,key(symbol?"ABC":"12#","",true,()->toggleSymbols(),null),1,57);add(bottom,key(predict?"T9 ✓":"T9 ×","",true,()->togglePrediction(),()->setCase()),.8f,57);add(bottom,spaceWithMic(),3,57);add(bottom,new DeleteKey(),1,57);add(bottom,key("↵","",true,()->enter(),null),1,57);
  }
 }
  // Space and microphone share one key. Hold for 2000 ms to start voice input.
  Key spaceWithMic(){return new SpaceMicKey();}
  class SpaceMicKey extends Key {
   static final long VOICE_HOLD_MS=2000L;
   boolean voiceTriggered=false, tracking=false;
   final Runnable activateVoice=()->{
    if(!tracking||voiceTriggered)return;
    voiceTriggered=true;
    setPressed(false);
    feedback(this);
    startVoiceInput();
   };
   SpaceMicKey(){super("Türkçe  🎙","",false,()->{},null);
    setContentDescription("Boşluk; 2 saniye basılı tutarak mikrofonu aç");
   }
   @Override public boolean onTouchEvent(MotionEvent event){
    switch(event.getActionMasked()){
     case MotionEvent.ACTION_DOWN:
      tracking=true;voiceTriggered=false;setPressed(true);
      handler.postDelayed(activateVoice,VOICE_HOLD_MS);
      return true;
     case MotionEvent.ACTION_MOVE:
      if(tracking&&(event.getX()<0||event.getX()>getWidth()||event.getY()<0||event.getY()>getHeight())){
       tracking=false;handler.removeCallbacks(activateVoice);setPressed(false);
      }
      return true;
     case MotionEvent.ACTION_UP:
      boolean insertSpace=tracking&&!voiceTriggered;
      tracking=false;handler.removeCallbacks(activateVoice);setPressed(false);
      if(insertSpace){feedback(this);space();}
      return true;
     case MotionEvent.ACTION_CANCEL:
      tracking=false;handler.removeCallbacks(activateVoice);setPressed(false);
      return true;
     default:return true;
    }
   }
   @Override protected void onDetachedFromWindow(){
    tracking=false;handler.removeCallbacks(activateVoice);super.onDetachedFromWindow();
   }
   @Override protected void onDraw(Canvas c){
    super.onDraw(c);
    paint.setColor(neon?0xff00f5ff:0xff12bae9);
    paint.setTextSize(dp(11));paint.setTextAlign(Paint.Align.LEFT);
    c.drawText(predict?"T9":"abc",dp(8),dp(16),paint);
   }
  }
 void showImeDialog(AlertDialog dialog){Window window=dialog.getWindow();WindowManager.LayoutParams attrs=window.getAttributes();attrs.token=root.getWindowToken();attrs.type=WindowManager.LayoutParams.TYPE_APPLICATION_ATTACHED_DIALOG;window.setAttributes(attrs);window.addFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);dialog.show();}
 void showQuickSettings(){finish();String[] choices={vibrate?"Titreşim: Açık":"Titreşim: Kapalı",prefs().getBoolean("auto_learning",true)?"Otomatik öğrenme: Açık":"Otomatik öğrenme: Kapalı",prefs().getBoolean("clipboard_history",true)?"Pano geçmişi: Açık":"Pano geçmişi: Kapalı","Tüm ayarlar ve sözlüğüm"};showImeDialog(new AlertDialog.Builder(this).setTitle("Ayarlar").setItems(choices,(d,which)->{if(which==0){vibrate=!vibrate;prefs().edit().putBoolean("vibrate",vibrate).apply();}else if(which==1)prefs().edit().putBoolean("auto_learning",!prefs().getBoolean("auto_learning",true)).apply();else if(which==2)prefs().edit().putBoolean("clipboard_history",!prefs().getBoolean("clipboard_history",true)).apply();else{Intent intent=new Intent(this,MainActivity.class);intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(intent);}}).setNegativeButton("Kapat",null).create());}
 void showThemeOptions(){finish();showImeDialog(new AlertDialog.Builder(this).setTitle("Tema").setSingleChoiceItems(new String[]{"Neon (turkuaz / mor)","Koyu gri","Açık"},neon?0:(dark?1:2),(d,which)->{neon=which==0;dark=which!=2;prefs().edit().putBoolean("neon",neon).putBoolean("dark",dark).apply();d.dismiss();rebuild();}).setNegativeButton("Kapat",null).create());}
 void showKeyboardOptions(){finish();showImeDialog(new AlertDialog.Builder(this).setTitle("Klavye").setItems(new String[]{"Türkçe 3×4","Türkçe QWERTY",shift?"Küçük harfe geç":"Büyük harfe geç","Telefondaki diğer klavyeler"},(d,which)->{if(which==3){((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker();return;}if(which==2){setCase();return;}qwerty=which==1;symbol=false;clipboardMode=false;prefs().edit().putBoolean("qwerty",qwerty).apply();rebuild();}).setNegativeButton("Kapat",null).create());}
 ClipboardManager clipboardManager;ClipboardManager.OnPrimaryClipChangedListener clipboardListener;ClipboardHistory clips=new ClipboardHistory();boolean clipboardMode=false,currentClipSensitive=false;String currentClip="";
 void setupClipboard(){clips.load(prefs().getString("clipboard_clips",""));clipboardManager=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);clipboardListener=()->{if(isInputViewShown()){captureClipboard();if(clipboardMode)rebuild();}};if(clipboardManager!=null)clipboardManager.addPrimaryClipChangedListener(clipboardListener);}
 void captureClipboard(){currentClip="";currentClipSensitive=false;if(clipboardManager==null)return;try{ClipData data=clipboardManager.getPrimaryClip();if(data==null||data.getItemCount()==0)return;ClipDescription description=data.getDescription();currentClipSensitive=description!=null&&description.getExtras()!=null&&description.getExtras().getBoolean("android.content.extra.IS_SENSITIVE",false);StringBuilder text=new StringBuilder();for(int i=0;i<data.getItemCount()&&text.length()<4000;i++){CharSequence part=data.getItemAt(i).getText();if(part!=null){if(text.length()>0)text.append('\n');int remaining=4000-text.length();if(remaining>0)text.append(part,0,Math.min(part.length(),remaining));}}currentClip=text.substring(0,Math.min(text.length(),4000));if(!currentClipSensitive&&!privateField&&prefs().getBoolean("clipboard_history",true)&&!currentClip.trim().isEmpty()){clips.add(currentClip);prefs().edit().putString("clipboard_clips",clips.save()).apply();}}catch(SecurityException ignored){}}
 void renderClipboard(){LinearLayout actions=line(root);add(actions,key("Geri","",true,()->{clipboardMode=false;rebuild();},null),1,38);add(actions,key("Geçmişi temizle","",true,()->{clips.clear();prefs().edit().putString("clipboard_clips","").apply();rebuild();},null),2,38);ScrollView scroll=new ScrollView(this);LinearLayout list=new LinearLayout(this);list.setOrientation(1);scroll.addView(list);root.addView(scroll,new LinearLayout.LayoutParams(-1,dp(265)));LinkedHashMap<String,String> items=new LinkedHashMap<>();if(!currentClip.isEmpty())items.put(currentClip,currentClipSensitive?"Hassas pano içeriğini yapıştır (geçmişe kaydedilmez)":currentClip);for(String text:clips.list())if(!items.containsKey(text))items.put(text,text);if(items.isEmpty()){TextView empty=new TextView(this);empty.setText("Pano boş. Bir cümleyi kopyalayıp burayı yeniden aç. Klavye açıkken görülen son 20 metin yerel olarak saklanabilir.");empty.setTextColor(0xffcccccc);empty.setPadding(dp(12),dp(14),dp(12),dp(14));list.addView(empty);}for(Map.Entry<String,String> item:items.entrySet()){TextView t=new TextView(this);t.setText(item.getValue());t.setTextColor(dark?0xfff0eff2:0xff252931);t.setTextSize(17);t.setMaxLines(3);t.setEllipsize(android.text.TextUtils.TruncateAt.END);t.setPadding(dp(12),dp(12),dp(12),dp(12));t.setBackgroundColor(dark?0xff3d3b40:0xffececf0);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(dp(2),dp(3),dp(2),dp(3));list.addView(t,p);t.setOnClickListener(v->{finish();commit(item.getKey());wordClosed=false;clipboardMode=false;rebuild();});}}
 int voicePolls=0;Runnable voicePoll=new Runnable(){public void run(){if(serviceDestroyed||!VoiceBridge.hasRequest(SystemClock.elapsedRealtime()))return;tryInsertVoice();if(++voicePolls<240&&VoiceBridge.hasRequest(SystemClock.elapsedRealtime()))handler.postDelayed(this,500);}};
 void startVoiceInput(){if(privateField){Toast.makeText(this,"Şifre alanında sesli yazma kapalı.",Toast.LENGTH_SHORT).show();return;}EditorInfo e=getCurrentInputEditorInfo();if(e==null)return;finish();flushLearned();String token=VoiceBridge.begin(e.packageName,e.fieldId,e.inputType,SystemClock.elapsedRealtime());Intent intent=new Intent(this,VoiceInputActivity.class);intent.putExtra("request",token);intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);try{startActivity(intent);voicePolls=0;handler.removeCallbacks(voicePoll);handler.postDelayed(voicePoll,500);}catch(RuntimeException error){VoiceBridge.cancel(token);Toast.makeText(this,"Sesli yazma ekranı açılamadı.",Toast.LENGTH_SHORT).show();}}
 void tryInsertVoice(){if(!isInputViewShown()||privateField)return;EditorInfo e=getCurrentInputEditorInfo();if(e==null)return;String text=VoiceBridge.pending(e.packageName,e.fieldId,e.inputType,SystemClock.elapsedRealtime());InputConnection ic=getCurrentInputConnection();if(text==null||ic==null)return;finish();if(ic.commitText(text,1)){VoiceBridge.clear();wordClosed=false;if(fieldAllowsLearning&&prefs().getBoolean("auto_learning",true)){learned.learnSentence(text);learnedDirty=true;flushLearned();}updateTypedPrediction();}}
  // The four left punctuation keys can be reassigned by holding each key.
  static final String[] PUNCTUATION_CHOICES={"!","?","'","~",",",";",":","@","#","-","_","/","(",")","+","="};
  void configurePunctuation(int slot){
   showImeDialog(new AlertDialog.Builder(this).setTitle("Sol işaret tuşunu özelleştir")
    .setItems(PUNCTUATION_CHOICES,(dialog,which)->{
     prefs().edit().putString("punctuation_"+slot,PUNCTUATION_CHOICES[which]).apply();updateSide();
    }).setNegativeButton("Vazgeç",null).create());
  }
  void updateSide(){
   if(sideLetters==null)return;
   sideLetters.removeAllViews();
   String[] defaults={"!","?","'","~"};
   boolean correcting=predict&&!privateField&&!digits.isEmpty();
   String chars=correcting?groups[digits.charAt(digits.length()-1)-'0']:"";
   for(int i=0;i<4;i++){
    final int slot=i;
    final String sign=correcting?(i<chars.length()?String.valueOf(chars.charAt(i)):"·"):prefs().getString("punctuation_"+i,defaults[i]);
    Key k=key(sign,"",true,()->{
     if(correcting){if(!"·".equals(sign))correctLastT9Letter(sign);}else literal(sign);
    },correcting?null:()->configurePunctuation(slot));
    LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,0,1);
    params.setMargins(dp(1),dp(1),dp(1),dp(1));sideLetters.addView(k,params);
   }
  }
  void correctLastT9Letter(String letter){
   InputConnection ic=getCurrentInputConnection();if(ic==null||digits.isEmpty())return;
   String before=digits.substring(0,digits.length()-1);
   StringBuilder literal=new StringBuilder();for(int i=0;i<before.length();i++)literal.append(groups[before.charAt(i)-'0'].charAt(0));
   literal.append(letter);digits="";options.clear();ic.setComposingText(shift?literal.toString().toUpperCase(tr):literal.toString(),1);ic.finishComposingText();updateTypedPrediction();updateSide();
  }

 void rebuild(){render();setInputView(root);} void commit(String s){InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.commitText(s,1);}
 void tap(int n){wordClosed=false;nextSuggestions=false;typedPrefix="";if(n==1){finish();commit(".");return;}if(predict&&!privateField){finishMulti();if(resumeAccepted(n))return;digits+=n;updatePrediction();}else{long now=SystemClock.uptimeMillis();if(n==last&&now-lastTime<800){index=(index+1)%groups[n].length();}else{finishMulti();last=n;index=0;}multi=String.valueOf(groups[n].charAt(index));InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.setComposingText(shift?multi.toUpperCase(tr):multi,1);lastTime=now;handler.removeCallbacks(timeout);handler.postDelayed(timeout,800);updateTypedPrediction();}}
 boolean resumeAccepted(int n){if(acceptedWord.isEmpty()||!digits.isEmpty())return false;String saved=acceptedWord;acceptedWord="";InputConnection ic=getCurrentInputConnection();if(ic==null)return false;CharSequence before=ic.getTextBeforeCursor(saved.length(),0),selected=ic.getSelectedText(0);if(before==null||!before.toString().equals(saved)||(selected!=null&&selected.length()>0))return false;ic.beginBatchEdit();try{if(!ic.deleteSurroundingText(saved.length(),0))return false;digits=code(saved)+n;updatePrediction();return true;}finally{ic.endBatchEdit();}}
 public void onUpdateSelection(int os,int oe,int ns,int ne,int cs,int ce){super.onUpdateSelection(os,oe,ns,ne,cs,ce);if((!digits.isEmpty()||!multi.isEmpty())&&ce>=0&&(ns!=ce||ne!=ce)){handler.removeCallbacks(timeout);InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.finishComposingText();digits="";multi="";last=-1;refresh();}}
 void finishMulti(){handler.removeCallbacks(timeout);InputConnection ic=getCurrentInputConnection();if(!multi.isEmpty()&&ic!=null)ic.finishComposingText();multi="";last=-1;}
 void addOptions(Collection<String> values,int limit){for(String w:values)if(options.size()<limit&&!options.contains(w))options.add(w);}
 void collectOptions(String prefix,boolean t9){options.clear();if(prefix.isEmpty())return;
  if(fieldAllowsLearning)addOptions(learned.matching(prefix,t9,10),40);
  for(String w:new TreeSet<>(prefs().getStringSet("words",new HashSet<String>())))if((t9?code(w):w).startsWith(prefix)&&options.size()<16)addOptions(Collections.singletonList(w),40);
  if(t9){ArrayList<String> exact=dict.get(prefix);if(exact!=null)addOptions(exact,40);}
  InflectedDictionary extended=inflected;if(extended!=null){List<String> exact=extended.lookup(t9?prefix:code(prefix),40);for(String w:exact)if(t9||w.startsWith(prefix))addOptions(Collections.singletonList(w),40);}
  for(Map.Entry<String,String> e:basicCodes.entrySet())if((t9?e.getValue():e.getKey()).startsWith(prefix)&&options.size()<30)addOptions(Collections.singletonList(e.getKey()),40);
  if(extended!=null&&options.size()<40)addOptions(extended.complete(t9?prefix:code(prefix),t9?null:prefix,40-options.size()),40);
 }
 void updatePrediction(){typedPrefix="";nextSuggestions=false;collectOptions(digits,true);String composing;
  if(options.isEmpty()){StringBuilder b=new StringBuilder();for(char c:digits.toCharArray())b.append(groups[c-'0'].charAt(0));composing=b.toString();options.add(composing);}else composing=options.get(0).substring(0,Math.min(digits.length(),options.get(0).length()));
  InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.setComposingText(shift?composing.toUpperCase(tr):composing,1);refresh();updateSide();
 }
 String currentTypedWord(){InputConnection ic=getCurrentInputConnection();if(ic==null)return "";CharSequence before=ic.getTextBeforeCursor(64,0);if(before==null)return "";String text=LearningDictionary.normalize(before.toString());int i=text.length();while(i>0&&Character.isLetter(text.charAt(i-1)))i--;String w=text.substring(i);return w.matches("[a-zçğıöşü]{1,40}")?w:"";}
 void updateTypedPrediction(){nextSuggestions=false;typedPrefix="";if(!predict||privateField){options.clear();refresh();return;}typedPrefix=currentTypedWord();collectOptions(typedPrefix,false);refresh();}
 void chooseSuggestion(String w){InputConnection ic=getCurrentInputConnection();if(ic==null)return;CharSequence selectedNow=ic.getSelectedText(0);if(selectedNow!=null&&selectedNow.length()>0)return;String chosen=shift?w.toUpperCase(tr):w;
  if(digits.isEmpty()&&!nextSuggestions){String current=currentTypedWord();if(current.isEmpty())return;CharSequence before=ic.getTextBeforeCursor(current.length(),0),selection=ic.getSelectedText(0);if(before==null||!LearningDictionary.normalize(before.toString()).equals(current)||(selection!=null&&selection.length()>0))return;finishMulti();ic.beginBatchEdit();try{if(!ic.deleteSurroundingText(current.length(),0))return;commit(chosen);}finally{ic.endBatchEdit();}}
  else commit(chosen);
  ic.finishComposingText();commit(" ");
  digits="";typedPrefix="";nextSuggestions=false;acceptedWord="";wordClosed=true;options.clear();showNextSuggestions();updateSide();
 }
 void showNextSuggestions(){digits="";typedPrefix="";options.clear();nextSuggestions=false;if(predict&&fieldAllowsLearning&&!privateField){InputConnection ic=getCurrentInputConnection();CharSequence raw=ic==null?null:ic.getTextBeforeCursor(128,0);if(raw!=null&&!raw.toString().matches("(?s).*[.!?]\\s*$")){List<String> ws=LearningDictionary.tokenize(raw.toString());if(!ws.isEmpty()){addOptions(learned.next(ws.get(ws.size()-1),8),8);nextSuggestions=!options.isEmpty();}}}refresh();}
 boolean learnedDirty=false;Runnable saveLearned=()->flushLearned();
 void loadLearned(){learned.load(prefs().getStringSet("learned_words",new HashSet<String>()),prefs().getStringSet("learned_pairs",new HashSet<String>()));}
 void flushLearned(){handler.removeCallbacks(saveLearned);if(!learnedDirty)return;prefs().edit().putStringSet("learned_words",learned.exportWords()).putStringSet("learned_pairs",learned.exportPairs()).apply();learnedDirty=false;}
 void learnBoundary(){if(wordClosed)return;wordClosed=true;if(!fieldAllowsLearning||privateField||!prefs().getBoolean("auto_learning",true))return;InputConnection ic=getCurrentInputConnection();CharSequence before=ic==null?null:ic.getTextBeforeCursor(256,0);if(before==null)return;String raw=before.toString();String[] chunks=raw.split("\\s+");String tail=chunks.length==0?"":chunks[chunks.length-1];if(tail.contains("@")||tail.contains("://")||tail.matches(".*[0-9].*"))return;int cut=Math.max(Math.max(raw.lastIndexOf('.'),raw.lastIndexOf('!')),Math.max(raw.lastIndexOf('?'),raw.lastIndexOf('\n')));String section=raw.substring(cut+1);List<String> ws=LearningDictionary.tokenize(section);String word=currentTypedWord();if(ws.isEmpty()||!ws.get(ws.size()-1).equals(word))return;String prev=ws.size()>1?ws.get(ws.size()-2):"";learned.learn(prev,word);learnedDirty=true;handler.removeCallbacks(saveLearned);handler.postDelayed(saveLearned,600);}
 void refresh(){if(candidates==null)return;candidates.removeAllViews();boolean empty=digits.isEmpty()&&typedPrefix.isEmpty()&&!nextSuggestions;if(suggestionStrip!=null)suggestionStrip.setVisibility(empty?View.GONE:View.VISIBLE);if(empty)return;for(String w:options){TextView t=new TextView(this);t.setText(shift?w.toUpperCase(tr):w);t.setTextColor(neon?(options.indexOf(w)==0?0xff00f5ff:0xffd3a0ff):(options.indexOf(w)==0?0xff08bce9:0xffc5c2c8));t.setTextSize(24);t.setPadding(dp(15),dp(7),dp(15),dp(7));t.setOnClickListener(v->{chooseSuggestion(w);});candidates.addView(t);}}
 void finish(){typedPrefix="";nextSuggestions=false;options.clear();acceptedWord="";finishMulti();if(!digits.isEmpty()){InputConnection ic=getCurrentInputConnection();if(ic!=null)ic.finishComposingText();digits="";refresh();}}
 void space(){InputConnection ic=getCurrentInputConnection();CharSequence before=ic==null?null:ic.getTextBeforeCursor(1,0);if(wordClosed&&before!=null&&" ".contentEquals(before)){showNextSuggestions();return;}learnBoundary();finish();commit(" ");showNextSuggestions();updateSide();} void back(){wordClosed=false;acceptedWord="";nextSuggestions=false;InputConnection ic=getCurrentInputConnection();if(ic==null)return;if(!digits.isEmpty()){digits=digits.substring(0,digits.length()-1);if(digits.isEmpty()){ic.setComposingText("",1);ic.finishComposingText();refresh();}else updatePrediction();}else if(!multi.isEmpty()){handler.removeCallbacks(timeout);ic.setComposingText("",1);ic.finishComposingText();multi="";last=-1;updateTypedPrediction();}else{ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN,KeyEvent.KEYCODE_DEL));ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP,KeyEvent.KEYCODE_DEL));updateTypedPrediction();}}
 void enter(){learnBoundary();finish();InputConnection ic=getCurrentInputConnection();if(ic==null)return;int a=getCurrentInputEditorInfo().imeOptions&EditorInfo.IME_MASK_ACTION;if((getCurrentInputEditorInfo().imeOptions&EditorInfo.IME_FLAG_NO_ENTER_ACTION)==0&&a!=EditorInfo.IME_ACTION_NONE&&a!=EditorInfo.IME_ACTION_UNSPECIFIED)ic.performEditorAction(a);else commit("\n");typedPrefix="";options.clear();nextSuggestions=false;refresh();}
}
