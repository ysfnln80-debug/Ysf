package tr.klasik.klavye;
public final class LearningPolicy {
 private LearningPolicy(){}
 public static boolean allows(int inputType,int imeOptions){
  if((inputType&15)!=1||(imeOptions&0x01000000)!=0||(inputType&0x00080000)!=0)return false;
  int variation=inputType&0x00000ff0;
  // URI, email, password, visible password, web email/password, personal name/address.
  return variation!=0x10&&variation!=0x20&&variation!=0x80&&variation!=0x90&&variation!=0xd0&&variation!=0xe0&&variation!=0x60&&variation!=0x70;
 }
}
